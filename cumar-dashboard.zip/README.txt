# Cumar Dashboard

Website dashboard/portfolio oo ku shaqaynaya GitHub Pages.

## Waxa ku jira
- Dashboard qurux badan oo responsive ah
- Projects: Add / Edit / Delete
- Filters iyo Search
- Skills: Add / Edit / Delete
- Profile: Edit / Save
- Dark mode
- Xogta browser-ka waxaa lagu kaydiyaa localStorage
- Project image URL waa lagu dari karaa

## GitHub Pages
Upload `index.html`, `style.css`, iyo `script.js` isla folder-ka repository-ga. GitHub Pages-na ka dhig `main` + `/ (root)`.

**Fiiro gaar ah:** localStorage wuxuu xogta ku hayaa browser-ka/qalabkaas oo keliya. Haddii aad rabto login iyo xog meel kasta laga geli karo, waxaa loo baahan yahay database/backend (tusaale Firebase/Supabase).
