const defaultProjects=[
 {id:1,name:"Personal Website",description:"Website-ka portfolio-ga iyo xogtayda shaqsiyeed.",category:"Website",status:"Completed",image:""},
 {id:2,name:"Python Calculator",description:"Calculator aan ku sameeyay Python si aan u barto programming.",category:"Python",status:"In Progress",image:""},
 {id:3,name:"Dashboard UI",description:"Dashboard casri ah oo leh filters iyo maamulka xogta.",category:"Design",status:"Idea",image:""}
];
const defaultSkills=[
 {id:1,name:"Python",level:75},{id:2,name:"HTML",level:90},{id:3,name:"CSS",level:80},{id:4,name:"JavaScript",level:65}
];
const defaultProfile={name:"Cumar",about:"Waxaan baranayaa programming iyo website development.",email:"",phone:"",website:""};

let projects=JSON.parse(localStorage.getItem("cumar_projects"))||defaultProjects;
let skills=JSON.parse(localStorage.getItem("cumar_skills"))||defaultSkills;
let profile=JSON.parse(localStorage.getItem("cumar_profile"))||defaultProfile;

const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);
function save(){localStorage.setItem("cumar_projects",JSON.stringify(projects));localStorage.setItem("cumar_skills",JSON.stringify(skills));localStorage.setItem("cumar_profile",JSON.stringify(profile));renderAll();}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function section(name){$$(".section").forEach(x=>x.classList.remove("active"));$(`#${name}`).classList.add("active");$$(".nav-btn[data-section]").forEach(x=>x.classList.toggle("active",x.dataset.section===name));$("#pageTitle").textContent=name[0].toUpperCase()+name.slice(1);if(innerWidth<701)$("#sidebar").classList.remove("open")}
$$(".nav-btn[data-section]").forEach(b=>b.onclick=()=>section(b.dataset.section));
$$("[data-section-jump]").forEach(b=>b.onclick=()=>section(b.dataset.sectionJump));
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
$("#themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("cumar_dark",document.body.classList.contains("dark"))};
if(localStorage.getItem("cumar_dark")==="true")document.body.classList.add("dark");

function projectImage(p){return p.image?`style="background-image:url('${p.image.replaceAll("'","")}')"`:""}
function renderProjects(){
 const q=($("#projectSearch")?.value||$("#globalSearch")?.value||"").toLowerCase();
 const cat=$("#categoryFilter")?.value||"all", st=$("#statusFilter")?.value||"all";
 const list=projects.filter(p=>(p.name+p.description+p.category).toLowerCase().includes(q)&&(cat==="all"||p.category===cat)&&(st==="all"||p.status===st));
 $("#projectsGrid").innerHTML=list.map(p=>`<article class="project-card">
   <div class="project-img" ${projectImage(p)}>🖥️</div><div class="project-body"><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p>
   <div class="tags"><span class="tag">${esc(p.category)}</span><span class="status ${p.status==="In Progress"?"progress":p.status==="Idea"?"idea":""}">${esc(p.status)}</span></div>
   <div class="card-actions"><button class="icon-btn" onclick="editProject(${p.id})">✏️ Edit</button><button class="icon-btn" onclick="deleteProject(${p.id})">🗑️ Delete</button></div></div></article>`).join("")||`<div class="panel"><h3>No projects found</h3><p>Ku dar project cusub.</p></div>`;
}
function renderSkills(){
 $("#skillsGrid").innerHTML=skills.map(s=>`<article class="skill-card"><h3>${esc(s.name)}</h3><div class="level">${s.level}%</div><div class="bar"><span style="width:${s.level}%"></span></div><div class="card-actions"><button class="icon-btn" onclick="editSkill(${s.id})">✏️ Edit</button><button class="icon-btn" onclick="deleteSkill(${s.id})">🗑️ Delete</button></div></article>`).join("");
 $("#dashboardSkills").innerHTML=skills.slice(0,5).map(s=>`<div class="skill-row"><div class="skill-top"><span>${esc(s.name)}</span><strong>${s.level}%</strong></div><div class="bar"><span style="width:${s.level}%"></span></div></div>`).join("");
}
function renderDashboard(){
 $("#projectCount").textContent=projects.length;$("#skillCount").textContent=skills.length;$("#completedCount").textContent=projects.filter(p=>p.status==="Completed").length;
 const avg=projects.length?Math.round(projects.reduce((a,p)=>a+(p.status==="Completed"?100:p.status==="In Progress"?50:10),0)/projects.length):0;$("#progressCount").textContent=avg+"%";
 $("#recentProjects").innerHTML=projects.slice(-4).reverse().map(p=>`<div class="mini"><div class="mini-img">🖥️</div><div><strong>${esc(p.name)}</strong><small>${esc(p.category)} · ${esc(p.status)}</small></div></div>`).join("");
}
function renderProfile(){$("#profileName").value=profile.name;$("#profileAbout").value=profile.about;$("#profileEmail").value=profile.email;$("#profilePhone").value=profile.phone;$("#profileWebsite").value=profile.website}
function renderAll(){renderProjects();renderSkills();renderDashboard();renderProfile()}
function esc(x){return String(x).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}

function openModal(id){$(id).classList.add("open")}function closeModal(id){$(id).classList.remove("open")}
$$("[data-close]").forEach(b=>b.onclick=()=>closeModal("#"+b.dataset.close));

$("#addProjectBtn").onclick=()=>{ $("#projectForm").reset();$("#projectId").value="";$("#projectModalTitle").textContent="Add Project";openModal("#projectModal") };
$("#projectForm").onsubmit=e=>{e.preventDefault();const id=$("#projectId").value;const obj={id:id?Number(id):Date.now(),name:$("#projectName").value.trim(),description:$("#projectDescription").value.trim(),category:$("#projectCategory").value,status:$("#projectStatus").value,image:$("#projectImage").value.trim()};if(id)projects=projects.map(p=>p.id===Number(id)?obj:p);else projects.push(obj);save();closeModal("#projectModal");toast("Project waa la keydiyay ✅")};
window.editProject=id=>{const p=projects.find(x=>x.id===id);$("#projectId").value=p.id;$("#projectName").value=p.name;$("#projectDescription").value=p.description;$("#projectCategory").value=p.category;$("#projectStatus").value=p.status;$("#projectImage").value=p.image||"";$("#projectModalTitle").textContent="Edit Project";openModal("#projectModal")};
window.deleteProject=id=>{if(confirm("Ma hubtaa inaad tirtirayso project-kan?")){projects=projects.filter(p=>p.id!==id);save();toast("Project waa la tirtiray 🗑️")}};

$("#addSkillBtn").onclick=()=>{ $("#skillForm").reset();$("#skillId").value="";$("#skillLevel").value=70;$("#levelValue").textContent=70;$("#skillModalTitle").textContent="Add Skill";openModal("#skillModal") };
$("#skillLevel").oninput=e=>$("#levelValue").textContent=e.target.value;
$("#skillForm").onsubmit=e=>{e.preventDefault();const id=$("#skillId").value;const obj={id:id?Number(id):Date.now(),name:$("#skillName").value.trim(),level:Number($("#skillLevel").value)};if(id)skills=skills.map(s=>s.id===Number(id)?obj:s);else skills.push(obj);save();closeModal("#skillModal");toast("Skill waa la keydiyay ✅")};
window.editSkill=id=>{const s=skills.find(x=>x.id===id);$("#skillId").value=s.id;$("#skillName").value=s.name;$("#skillLevel").value=s.level;$("#levelValue").textContent=s.level;$("#skillModalTitle").textContent="Edit Skill";openModal("#skillModal")};
window.deleteSkill=id=>{if(confirm("Ma hubtaa inaad tirtirayso skill-kan?")){skills=skills.filter(s=>s.id!==id);save();toast("Skill waa la tirtiray 🗑️")}};

$("#saveProfileBtn").onclick=()=>{profile={name:$("#profileName").value.trim(),about:$("#profileAbout").value.trim(),email:$("#profileEmail").value.trim(),phone:$("#profilePhone").value.trim(),website:$("#profileWebsite").value.trim()};save();toast("Profile waa la keydiyay ✅")};
$("#projectSearch").oninput=renderProjects;$("#categoryFilter").onchange=renderProjects;$("#statusFilter").onchange=renderProjects;$("#globalSearch").oninput=()=>{section("projects");$("#projectSearch").value=$("#globalSearch").value;renderProjects()};
$("#resetBtn").onclick=()=>{if(confirm("Tani waxay soo celinaysaa xogtii demo-ga. Sii wad?")){projects=JSON.parse(JSON.stringify(defaultProjects));skills=JSON.parse(JSON.stringify(defaultSkills));profile=JSON.parse(JSON.stringify(defaultProfile));save();toast("Demo data waa la soo celiyay")}};
renderAll();
